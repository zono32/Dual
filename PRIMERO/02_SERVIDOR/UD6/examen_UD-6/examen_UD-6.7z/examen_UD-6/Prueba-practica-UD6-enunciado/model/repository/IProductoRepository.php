<?php


interface IProductoRepository extends IBaseRepository{

}
