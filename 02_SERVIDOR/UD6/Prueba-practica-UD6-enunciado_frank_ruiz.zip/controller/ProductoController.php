<?php

 class ProductoController 
{
    const VIEW_FOLDER = "producto";

    public $page_title;
    public $view;
    private ProductoServicio $productoServicio;

    public function __construct() {
        $this->view = self::VIEW_FOLDER . DIRECTORY_SEPARATOR . 'list_producto';
        $this->page_title = 'Productos';
        $this->productoServicio = new ProductoServicio();
  
    }

    public function list(){
        return $this->productoServicio->list();
    }

    public function delete(){
        $id = $_POST["id"];
        $resp = $this->productoServicio->delete($id);
        $_SESSION["error"] = $resp;
        header("Location: FrontController.php?controller=producto&action=list");
        exit;
        // return $resp;
    }
}
