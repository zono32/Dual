<?php

class ProductoServicio{


    private IProductoRepository $repository;


    public function __construct() {
        $this->repository = new ProductoRepository();
    }

    public function  list(){
      return  $this->repository->findAll();
    }

    public function delete($id){
        return $this->repository->delete($id);
    }

}