//prueba de alertas y confirmacion
'use strict'
alert("Prueba de alerta");

var miresultado=confirm("Estas seguro de querer continuar");
console.log(miresultado);