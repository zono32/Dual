<?php


if (isset($_POST["email"]) && ($_POST["pwd"]) && ($_POST["newPwd1"]) && ($_POST["newPwd2"])) {

    $email = $_POST["email"];
    $pass = $_POST["pwd"];
    $pass1 = $_POST["newPwd1"];
    $pass2 = $_POST["newPwd2"];

    $keys =array_keys($usuarios);
    print_r($keys);

    /**
     * Summary of comprobar_usuario
     * @param string $email
     * @return string
     */
    function comprobar_usuario(string $email): bool{
        global $email;      
        global $keys;
        global $pass;
        $count = sizeof([$keys[0]]);

        for ($i=0; $i<$count; $i++) { 
            if( $email == $keys[0]);
            return true; 
        }
           
        
                
    }

    if (comprobar_usuario($email) == false) {
        echo USER_DOES_NOT_EXIST;
    } else {
        echo "ok";}


    function comprobar_contraseña(string $pass): bool{
        global $pass;
        global $usuarios;

        foreach ($usuarios as $key => $value) {
            if( $pass != $usuarios[$key][$value]);
            
        }
        return false;        
    }



    
}
?>