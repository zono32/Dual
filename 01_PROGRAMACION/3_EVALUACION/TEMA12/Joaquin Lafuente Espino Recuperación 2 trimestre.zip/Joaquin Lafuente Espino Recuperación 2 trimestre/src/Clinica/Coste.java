package Clinica;

public interface Coste {

    public abstract double calcularCoste();
}
