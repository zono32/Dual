package Clinica;

public class ExcepEdadNegativa extends Exception{
    public ExcepEdadNegativa() {
    }

    public ExcepEdadNegativa(String message) {
        super(message);
    }
}
