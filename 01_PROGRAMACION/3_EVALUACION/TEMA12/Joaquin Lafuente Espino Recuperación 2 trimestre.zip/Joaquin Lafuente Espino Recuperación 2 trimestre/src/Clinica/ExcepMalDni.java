package Clinica;

public class ExcepMalDni extends Exception{

    public ExcepMalDni() {
    }

    public ExcepMalDni(String message) {
        super(message);
    }
}
