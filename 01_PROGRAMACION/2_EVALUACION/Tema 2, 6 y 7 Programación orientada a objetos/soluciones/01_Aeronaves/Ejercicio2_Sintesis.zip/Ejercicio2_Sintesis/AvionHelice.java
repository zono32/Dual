package Ejercicio2_Sintesis;

public class AvionHelice extends Aeronave {
    public AvionHelice(String id, int numPasajeros, int autonomiaMaxima, String modelo) {
        super(id, numPasajeros, autonomiaMaxima, modelo);
    }
}
